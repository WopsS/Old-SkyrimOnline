// proxydll.h
#pragma once

