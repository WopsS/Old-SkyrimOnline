#pragma once

#pragma unmanaged

void HookWinAPI();
void ReleaseWinAPI();
HWND WINAPI GetActiveWindow_c();