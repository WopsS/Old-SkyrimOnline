#include "stdafx.h"

std::ofstream file("hook.log", std::ios::trunc);