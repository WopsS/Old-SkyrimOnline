#pragma once

void SetGameScriptVariables(bool pForce = false);