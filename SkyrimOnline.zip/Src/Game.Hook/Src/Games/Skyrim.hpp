#pragma once

void InstallSkyrim();