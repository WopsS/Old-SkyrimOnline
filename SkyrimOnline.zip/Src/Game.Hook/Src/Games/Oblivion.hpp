#pragma once

void InstallOblivion();