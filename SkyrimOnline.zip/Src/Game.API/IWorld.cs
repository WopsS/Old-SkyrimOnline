﻿namespace Game.API
{
    public interface IWorld
    {
        void Update();

        void OnEnter();
    }
}