#include "common/IDebugStringBuffer.h"

IDebugStringBuffer	gDebugStringBuffer;
