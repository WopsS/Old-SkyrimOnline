#pragma once

class NiNode;

extern NiNode ** g_worldSceneGraph;
extern NiNode ** g_interfaceSceneGraph;
extern NiNode ** g_interface3DSceneGraph;
