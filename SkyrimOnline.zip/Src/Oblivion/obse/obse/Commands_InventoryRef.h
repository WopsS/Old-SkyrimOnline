#pragma once

#include "CommandTable.h"

extern CommandInfo kCommandInfo_RemoveMeIR;
extern CommandInfo kCommandInfo_CopyIR;
extern CommandInfo kCommandInfo_CreateTempRef;
extern CommandInfo kCommandInfo_GetInvRefsForItem;