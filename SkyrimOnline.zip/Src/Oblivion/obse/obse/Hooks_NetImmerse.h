#pragma once

void Hook_NetImmerse_Init(void);
void Hook_NetImmerse_DeInit(void);
