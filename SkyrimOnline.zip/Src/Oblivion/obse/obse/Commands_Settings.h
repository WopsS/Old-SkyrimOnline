#pragma once

#include "CommandTable.h"

extern CommandInfo kCommandInfo_EnableIniEdit;
extern CommandInfo kCommandInfo_IsIniEditEnabled;
extern CommandInfo kCommandInfo_SaveIni;
extern CommandInfo kCommandInfo_RefreshIni;
extern CommandInfo kCommandInfo_RestoreIni;
