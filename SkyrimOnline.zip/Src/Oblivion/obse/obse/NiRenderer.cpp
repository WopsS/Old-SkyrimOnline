#include "NiRenderer.h"

NiRenderer ** g_renderer = (NiRenderer **)0x00B3F928;
