#pragma once

#include "CommandTable.h"

extern CommandInfo kCommandInfo_FloatFromFile;
extern CommandInfo kCommandInfo_FloatToFile;
