#pragma once

struct IUpdatable
{
	virtual void Update() = 0;
};