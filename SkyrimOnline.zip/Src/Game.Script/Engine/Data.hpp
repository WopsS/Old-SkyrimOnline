#pragma once

#include "Engine/InputManager.h"

extern IDirect3DDevice9* TheIDirect3DDevice9;
extern IDirect3D9*	TheIDirect3D9;
extern IInputHook* TheIInputHook;
extern InputListener* TheInputListener;