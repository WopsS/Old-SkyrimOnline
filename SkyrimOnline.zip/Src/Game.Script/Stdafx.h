// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once


#include <list>
#include <vector>
#include <ctime>
#include <fstream>
#include <deque>
#include <unordered_map>
#include <cstdint>
#include <array>
#include <string>
#include <vector>
#include <sstream>

#include <d3d9.h>

#pragma warning( disable : 4251 )
#pragma warning( disable : 4244 )
#pragma warning( disable : 4996 )
#pragma warning( disable : 4355 )
