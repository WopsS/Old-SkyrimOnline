#pragma once

namespace Math
{
	class Vector3
	{
	public:
		float x,y,z;
	};
}