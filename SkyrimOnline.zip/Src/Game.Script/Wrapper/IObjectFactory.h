#pragma once 
#pragma managed

namespace Game
{
	public interface class IObjectFactory
	{
	public:


	};
}