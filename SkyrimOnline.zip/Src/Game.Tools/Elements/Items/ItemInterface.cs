﻿using Game.Tools.Elements.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Tools.Elements.Items
{
    interface Item
    {
        int Cunt { get; }
        ModelInterface model { get; }
    }
}
