﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Tools.Elements.Characters
{
    class TypeInterface
    {
        
        public static readonly short None = 0;
        public static readonly short Imperials = 1;
        public static readonly short Nord = 2;

    }
}
