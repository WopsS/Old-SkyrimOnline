﻿namespace Game.Tools.Language
{
    internal class LanguageConfig
    {
        private LanguageConfig(string pathToLanguageFile)
        {
        }
    }
}